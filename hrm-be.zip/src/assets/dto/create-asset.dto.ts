export class CreateAssetDto {
   
    itemCode:string;
    itemName:string;
    description:string;
    price:string;
    status:string;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string

}
