
export class CreateReceiptDto {

    date:string;
    reference:string;
    description:string;
    total:number;
    customerId:any;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string
 
}
