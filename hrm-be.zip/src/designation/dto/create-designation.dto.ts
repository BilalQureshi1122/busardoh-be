export class CreateDesignationDto {
    name:string;
    description:string;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string
}
