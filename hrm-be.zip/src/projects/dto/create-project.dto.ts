export class CreateProjectDto {
   
    name:string;
    description:string;
    startDate:string;
    endDate:string;
    income:string;
    directCost:string;
    profit:string;
    status:string;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string

}
