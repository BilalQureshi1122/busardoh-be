export class CreateDocumentDto {

    employeeId:any;
    employeeImage: any;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string


}
