export class CreatePayrollDto {}
