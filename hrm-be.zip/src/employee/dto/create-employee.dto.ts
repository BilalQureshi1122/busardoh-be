export class CreateEmployeeDto {
   
    name:string;
    email:string;
    description:string;
    phoneNumber:string;
    address:string;
    gender:string;
    image: string;
    departmentId:any;
    salary:any;
    designationId:any;
    dmlStatus:number;
    age: string;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string


}
