export class CreateAttendanceDto {

    employeeId:any;
    attendanceDate:Date;
    workLocation:string;
    projectId:any;
    checkIn:any;
    checkOut:any;
    late:any;
    halfDay:any;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string

}
