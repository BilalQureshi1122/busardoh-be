export class CreateDepartmentDto {
    name:string;
    description:string;
    phoneNumber:string;
    address:string;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string
}
