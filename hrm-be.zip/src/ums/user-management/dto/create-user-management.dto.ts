export class CreateUserManagementDto {

    name:string;
    email:string;
    mobileNumber:string;
    userName:string;
    password:string;
    dmlStatus:number;
    insertionTimeStamp:string;
    lastUpdateTimeStamp:string;
    closeTimeStamp:string

}
