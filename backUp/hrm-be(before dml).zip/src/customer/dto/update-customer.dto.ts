import { PartialType } from '@nestjs/mapped-types';
import { CreateCustomerDto } from './create-customer.dto';

export class UpdateCustomerDto extends PartialType(CreateCustomerDto) {
    
    name:string;
        email:string;
        phoneNumber:string;
        address:string;
        dmlStatus:number;
        timeStamp:string 
}
