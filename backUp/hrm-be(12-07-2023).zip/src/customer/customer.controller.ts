import { Controller, Get, Post, Body, Patch, Param, Delete, Req } from '@nestjs/common';
import { CustomerService } from './customer.service';
import { CreateCustomerDto, FindAllCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { Request } from 'express';

@Controller('customer')
export class CustomerController {
  constructor(private readonly customerService: CustomerService) {}

  @Post('/addCustomer')
  create(@Body() createCustomerDto: CreateCustomerDto) {
    return this.customerService.create(createCustomerDto);
  }

  // @Post('updateCustomer/'+':id')
  // update(@Param('id') id: string, @Body() updateCustomerDto: UpdateCustomerDto) {
  //   return this.customerService.update(+id, updateCustomerDto);
  // }
  @Post('updateCustomer')
  update(@Body() updateCustomerDto: UpdateCustomerDto) {
    return this.customerService.update(updateCustomerDto);
  }

  @Post('/getAllCustomer')
  findAll() {
    return this.customerService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.customerService.findOne(+id);
  }



  // @Delete('/deleteCustomer/'+':id')
  // remove(@Param('id') id: string) {
  //   return this.customerService.remove(+id);
  // }
   
  @Post('/deleteCustomer')
  removeSoft(@Body() updateCustomerDto: UpdateCustomerDto) {
    return this.customerService.delSoft(updateCustomerDto);
    
  }

  @Post('getAllCustomerPagination')
  async findAllCustomer(@Body() findAllCustomerDto) {
    
    try{
      this.customerService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
      console.log(findAllCustomerDto)
      return this.customerService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
     
    }
    catch(e){
      throw e
    }

//  return this.customerService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
  }
}
