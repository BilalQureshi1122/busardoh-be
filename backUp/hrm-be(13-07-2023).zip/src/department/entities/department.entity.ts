// import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Department {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  description: string;

  @Column()
  phoneNumber: string;

  @Column()
  address: string;

  @Column()
  dmlStatus: number;

  @Column()
  timeStamp:string

 
}