// import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
// import { SupplierService } from './supplier.service';
// import { CreateSupplierDto } from './dto/create-supplier.dto';
// import { UpdateSupplierDto } from './dto/update-supplier.dto';

// @Controller('supplier')
// export class SupplierController {
//   constructor(private readonly supplierService: SupplierService) {}

//   @Post()
//   create(@Body() createSupplierDto: CreateSupplierDto) {
//     return this.supplierService.create(createSupplierDto);
//   }

//   @Get()
//   findAll() {
//     return this.supplierService.findAll();
//   }

//   @Get(':id')
//   findOne(@Param('id') id: string) {
//     return this.supplierService.findOne(+id);
//   }

//   @Patch(':id')
//   update(@Param('id') id: string, @Body() updateSupplierDto: UpdateSupplierDto) {
//     return this.supplierService.update(+id, updateSupplierDto);
//   }

//   @Delete(':id')
//   remove(@Param('id') id: string) {
//     return this.supplierService.remove(+id);
//   }
// }




// import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
// import { ProjectsService } from './projects.service';
// import { createSupplierDto } from './dto/create-project.dto';
// import { updateSupplierDto } from './dto/update-project.dto';

// @Controller('projects')
// export class ProjectsController {
//   constructor(private readonly projectsService: ProjectsService) {}

//   @Post()
//   create(@Body() createSupplierDto: createSupplierDto) {
//     return this.projectsService.create(createSupplierDto);
//   }

//   @Get()
//   findAll() {
//     return this.projectsService.findAll();
//   }

//   @Get(':id')
//   findOne(@Param('id') id: string) {
//     return this.projectsService.findOne(+id);
//   }

//   @Patch(':id')
//   update(@Param('id') id: string, @Body() updateSupplierDto: updateSupplierDto) {
//     return this.projectsService.update(+id, updateSupplierDto);
//   }

//   @Delete(':id')
//   remove(@Param('id') id: string) {
//     return this.projectsService.remove(+id);
//   }
// }





import { Controller, Get, Post, Body, Patch, Param, Delete, Req } from '@nestjs/common';
import { SupplierService } from './supplier.service';
import { CreateSupplierDto } from './dto/create-supplier.dto';
import { UpdateSupplierDto } from './dto/update-supplier.dto';


@Controller('supplier')
export class SupplierController {
  constructor(private readonly supplierService: SupplierService) {}

  @Post('/addSupplier')
  create(@Body() createSupplierDto: CreateSupplierDto) {
    return this.supplierService.create(createSupplierDto);
  }

  // @Post('updateCustomer/'+':id')
  // update(@Param('id') id: string, @Body() updateSupplierDto: updateSupplierDto) {
  //   return this.supplierService.update(+id, updateSupplierDto);
  // }
  @Post('updateSupplier')
  update(@Body() updateSupplierDto: UpdateSupplierDto) {
    return this.supplierService.update(updateSupplierDto);
  }

  @Post('/getAllSupplier')
  findAll() {
    return this.supplierService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.supplierService.findOne(+id);
  }



  // @Delete('/deleteCustomer/'+':id')
  // remove(@Param('id') id: string) {
  //   return this.supplierService.remove(+id);
  // }
   
  @Post('/deleteSupplier')
  removeSoft(@Body() updateSupplierDto: UpdateSupplierDto) {
    return this.supplierService.delSoft(updateSupplierDto);
    
  }

  @Post('getAllSupplierPagination')
  async findAllSupplier(@Body() findAllCustomerDto) {
    
    try{
      this.supplierService.findAllSupplier(findAllCustomerDto,findAllCustomerDto.pagination)
      console.log(findAllCustomerDto)
      return this.supplierService.findAllSupplier(findAllCustomerDto,findAllCustomerDto.pagination)
     
    }
    catch(e){
      throw e
    }

//  return this.supplierService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
  }
}
