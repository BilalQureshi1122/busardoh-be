export class CreateSupplierDto {

    name:string;
    description:string;
    code:string;
    creditLimit:string;
    address:string;
    email:string;
    mobileNumber:string;
    startingBalance:string;
    dmlStatus:number;
    timeStamp:string
    

}
