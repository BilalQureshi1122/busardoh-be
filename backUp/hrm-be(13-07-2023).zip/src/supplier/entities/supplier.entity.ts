import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Supplier {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  description: string;

  @Column()
  code: string;

  @Column()
  creditLimit: string;

  @Column()
  address: string;

  @Column()
  email: string;

  @Column()
  mobileNumber: string;

  @Column()
  startingBalance: string;

  @Column()
  dmlStatus: number;

  @Column()
  timeStamp:string
 
}