// import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';


// @Controller('designation')
// export class DesignationController {
//   constructor(private readonly designationService: DesignationService) {}

//   @Post()
//   create(@Body() createDesignationDto: CreateDesignationDto) {
//     return this.designationService.create(createDesignationDto);
//   }

//   @Get()
//   findAll() {
//     return this.designationService.findAll();
//   }

//   @Get(':id')
//   findOne(@Param('id') id: string) {
//     return this.designationService.findOne(+id);
//   }

//   @Patch(':id')
//   update(@Param('id') id: string, @Body() updateDesignationDto: UpdateDesignationDto) {
//     return this.designationService.update(+id, updateDesignationDto);
//   }

//   @Delete(':id')
//   remove(@Param('id') id: string) {
//     return this.designationService.remove(+id);
//   }
// }

import { DesignationService } from './designation.service';
import { CreateDesignationDto } from './dto/create-designation.dto';
import { UpdateDesignationDto } from './dto/update-designation.dto';
import { Controller, Get, Post, Body, Patch, Param, Delete, Req } from '@nestjs/common';


@Controller('designation')
export class DesignationController {
  constructor(private readonly designationService: DesignationService) {}

  @Post('/addDesignation')
  create(@Body() createDesignationDto: CreateDesignationDto) {
    return this.designationService.create(createDesignationDto);
  }

  // @Post('updateCustomer/'+':id')
  // update(@Param('id') id: string, @Body() updateDesignationDto: updateDesignationDto) {
  //   return this.designationService.update(+id, updateDesignationDto);
  // }
  @Post('updateDesignation')
  update(@Body() updateDesignationDto: UpdateDesignationDto) {
    return this.designationService.update(updateDesignationDto);
  }

  @Post('/getAllDesignation')
  findAll() {
    return this.designationService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.designationService.findOne(+id);
  }



  // @Delete('/deleteCustomer/'+':id')
  // remove(@Param('id') id: string) {
  //   return this.designationService.remove(+id);
  // }
   
  @Post('/deleteDesignation')
  removeSoft(@Body() updateDesignationDto: UpdateDesignationDto) {
    return this.designationService.delSoft(updateDesignationDto);
    
  }

  @Post('getAllDesignationPagination')
  async findAllCustomer(@Body() findAllCustomerDto) {
    
    try{
      this.designationService.findAllDesignation(findAllCustomerDto,findAllCustomerDto.pagination)
      console.log(findAllCustomerDto)
      return this.designationService.findAllDesignation(findAllCustomerDto,findAllCustomerDto.pagination)
     
    }
    catch(e){
      throw e
    }

//  return this.designationService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
  }
}
