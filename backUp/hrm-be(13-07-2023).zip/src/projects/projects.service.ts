// import { Injectable } from '@nestjs/common';
// import { CreateProjectDto } from './dto/create-project.dto';
// import { UpdateProjectDto } from './dto/update-project.dto';

// @Injectable()
// export class ProjectsService {
//   create(createProjectDto: CreateProjectDto) {
//     return 'This action adds a new project';
//   }

//   findAll() {
//     return `This action returns all projects`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} project`;
//   }

//   update(id: number, updateProjectDto: UpdateProjectDto) {
//     return `This action updates a #${id} project`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} project`;
//   }
// }




import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'rxjs/operators';
import { Project } from './entities/project.entity';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { PaginationDto } from 'src/customer/dto/create-customer.dto';




@Injectable()
export class ProjectsService {
     
  constructor(@InjectRepository(Project) private readonly projecterRepo:Repository<Project>){}

  create(createProjectDto:CreateProjectDto):Promise<Project> {
    const project=new Project();
    project.name=createProjectDto.name;
    project.description=createProjectDto.description;
    project.startDate=createProjectDto.startDate;
    project.endDate=createProjectDto.endDate;
    project.income=createProjectDto.income;
    project.directCost=createProjectDto.directCost;
    project.profit=createProjectDto.profit;
    project.status=createProjectDto.status;
    project.dmlStatus=1;
    project.timeStamp=Date()
    return  this.projecterRepo.save(project);
  }

  findAll():Promise<Project[]> {
    return this.projecterRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} projecter`;
  }

  update(updateProjectDto:UpdateProjectDto) {
    const project=new Project();
    project.name=updateProjectDto.name;
    project.description=updateProjectDto.description;
    project.startDate=updateProjectDto.startDate;
    project.endDate=updateProjectDto.endDate;
    project.income=updateProjectDto.income;
    project.directCost=updateProjectDto.directCost;
    project.profit=updateProjectDto.profit;
    project.status=updateProjectDto.status;
    project.id=updateProjectDto.id,
    project.dmlStatus=2;
    project.timeStamp=Date()
    return  this.projecterRepo.save(project);
  }


  // remove(id: number) {
  //   return this.projecterRepo.delete(id);
  // }

  delSoft(updateProjectDto:UpdateProjectDto) {
    const project=new Project();
    project.name=updateProjectDto.name;
    project.description=updateProjectDto.description;
    project.startDate=updateProjectDto.startDate;
    project.endDate=updateProjectDto.endDate;
    project.income=updateProjectDto.income;
    project.directCost=updateProjectDto.directCost;
    project.profit=updateProjectDto.profit;
    project.status=updateProjectDto.status;
    project.id=updateProjectDto.id;
    project.dmlStatus=3;
    project.timeStamp=Date()
    return this.projecterRepo.save(project);
  }

  async findAllProject(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` projecter.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and projecter.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and projecter.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and projecter.address like '%${params?.address}%' and `;
    }
     
    sql += ` projecter.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.projecterRepo
      .createQueryBuilder('projecter')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.projecterRepo
      .createQueryBuilder('projecter')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
