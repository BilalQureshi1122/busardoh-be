// import { Injectable } from '@nestjs/common';
// import { CreateDepartmentDto } from './dto/create-department.dto';
// import { UpdateDepartmentDto } from './dto/update-department.dto';

// @Injectable()
// export class DepartmentService {
//   create(createDepartmentDto: CreateDepartmentDto) {
//     return 'This action adds a new department';
//   }

//   findAll() {
//     return `This action returns all department`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} department`;
//   }

//   update(id: number, updateDepartmentDto: UpdateDepartmentDto) {
//     return `This action updates a #${id} department`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} department`;
//   }
// }






import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateDepartmentDto } from './dto/create-department.dto';
import { UpdateDepartmentDto } from './dto/update-department.dto';
import { Department } from './entities/department.entity';
import { PaginationDto } from 'src/customer/dto/create-customer.dto';


@Injectable()
export class DepartmentService {
     
  constructor(@InjectRepository(Department) private readonly departmentRepo:Repository<Department>){}

  create(createDepartmentDto:CreateDepartmentDto):Promise<Department> {
    const department=new Department();
    department.name=createDepartmentDto.name;
    department.description=createDepartmentDto.description;
    department.phoneNumber=createDepartmentDto.phoneNumber;
    department.address=createDepartmentDto.address;
    department.dmlStatus=1;
    department.timeStamp=Date()
    return  this.departmentRepo.save(department);
  }

  findAll():Promise<Department[]> {
    return this.departmentRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} departmenter`;
  }

  update(updateDepartmentDto:UpdateDepartmentDto) {
    const department=new Department();
    department.name=updateDepartmentDto.name;
    department.description=updateDepartmentDto.description;
    department.phoneNumber=updateDepartmentDto.phoneNumber;
    department.address=updateDepartmentDto.address;
    department.id=updateDepartmentDto.id,
    department.dmlStatus=2;
    department.timeStamp=Date()
    return  this.departmentRepo.save(department);
  }


  // remove(id: number) {
  //   return this.departmentRepo.delete(id);
  // }

  delSoft(updateDepartmentDto:UpdateDepartmentDto) {
    const department=new Department();
    department.name=updateDepartmentDto.name;
    department.description=updateDepartmentDto.description;
    department.phoneNumber=updateDepartmentDto.phoneNumber;
    department.address=updateDepartmentDto.address;
    department.id=updateDepartmentDto.id;
    department.dmlStatus=3;
    department.timeStamp=Date()
    return this.departmentRepo.save(department);
  }

  async findAlldepartment(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` department.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and department.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and department.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and department.address like '%${params?.address}%' and `;
    }
     
    sql += ` department.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.departmentRepo
      .createQueryBuilder('department')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.departmentRepo
      .createQueryBuilder('department')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
