// import { Injectable } from '@nestjs/common';
// import { CreateEmployeeDto } from './dto/create-employee.dto';
// import { UpdateEmployeeDto } from './dto/update-employee.dto';

// @Injectable()
// export class EmployeeService {
//   create(createEmployeeDto: CreateEmployeeDto) {
//     return 'This action adds a new employee';
//   }

//   findAll() {
//     return `This action returns all employee`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} employee`;
//   }

//   update(id: number, updateEmployeeDto: UpdateEmployeeDto) {
//     return `This action updates a #${id} employee`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} employee`;
//   }
// }

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { PaginationDto } from 'src/customer/dto/create-customer.dto';
import { Employee } from './entities/employee.entity';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';


@Injectable()
export class EmployeeService {
     
  constructor(@InjectRepository(Employee) private readonly employeeRepo:Repository<Employee>){}

  create(createEmployeeDto:CreateEmployeeDto):Promise<Employee> {
    const employee=new Employee();
    employee.name=createEmployeeDto.name;
    employee.email=createEmployeeDto.email;
    employee.phoneNumber=createEmployeeDto.phoneNumber;
    employee.address=createEmployeeDto.address;
    employee.gender=createEmployeeDto.gender;
    employee.age=createEmployeeDto.age;
    employee.image=createEmployeeDto.image;
    employee.dmlStatus=1;
    employee.timeStamp=Date()
    return  this.employeeRepo.save(employee);
  }

  findAll():Promise<Employee[]> {
    return this.employeeRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} employeeer`;
  }

  update(updateemployeeDto:UpdateEmployeeDto) {
    const employee=new Employee();
    employee.name=updateemployeeDto.name;
    employee.email=updateemployeeDto.email;
    employee.phoneNumber=updateemployeeDto.phoneNumber;
    employee.address=updateemployeeDto.address;
    employee.gender=updateemployeeDto.gender;
    employee.age=updateemployeeDto.age;
    employee.image=updateemployeeDto.image;
    employee.dmlStatus=2;
    employee.timeStamp=Date()
    return  this.employeeRepo.save(employee);
  }


  // remove(id: number) {
  //   return this.employeeRepo.delete(id);
  // }

  delSoft(updateemployeeDto:UpdateEmployeeDto) {
    const employee=new Employee();
    employee.name=updateemployeeDto.name;
    employee.name=updateemployeeDto.name;
    employee.email=updateemployeeDto.email;
    employee.phoneNumber=updateemployeeDto.phoneNumber;
    employee.address=updateemployeeDto.address;
    employee.gender=updateemployeeDto.gender;
    employee.age=updateemployeeDto.age;
    employee.image=updateemployeeDto.image;
    employee.dmlStatus=3;
    employee.timeStamp=Date()
    return this.employeeRepo.save(employee);
  }

  async findAllEmp(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` employee.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and employee.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and employee.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and employee.address like '%${params?.address}%' and `;
    }
     
    sql += ` employee.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.employeeRepo
      .createQueryBuilder('employee')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.employeeRepo
      .createQueryBuilder('employee')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
