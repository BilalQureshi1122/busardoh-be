import { Department } from "src/department/entities/department.entity";
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Employee {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  email: string;

  @Column()
  phoneNumber: string;

  @Column()
  address: string;

  @Column()
  gender: string;

  @Column()
  age: string;

  @Column()
  image: string;

  @Column()
  department: string;

  @Column()
  designation: string;

  @Column()
  dmlStatus: number;

  @Column()
  timeStamp:string
   

 
}