export class CreateEmployeeDto {
   
    name:string;
    email:string;
    description:string;
    phoneNumber:string;
    address:string;
    gender:string;
    image: string;
    department:string;
    designation:string;
    dmlStatus:number;
    timeStamp:string
  age: string;

}
