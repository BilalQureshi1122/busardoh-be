// import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
// import { EmployeeService } from './employee.service';
// import { CreateEmployeeDto } from './dto/create-employee.dto';
// import { UpdateEmployeeDto } from './dto/update-employee.dto';

// @Controller('employee')
// export class EmployeeController {
//   constructor(private readonly employeeService: EmployeeService) {}

//   @Post()
//   create(@Body() createEmployeeDto: CreateEmployeeDto) {
//     return this.employeeService.create(createEmployeeDto);
//   }

//   @Get()
//   findAll() {
//     return this.employeeService.findAll();
//   }

//   @Get(':id')
//   findOne(@Param('id') id: string) {
//     return this.employeeService.findOne(+id);
//   }

//   @Patch(':id')
//   update(@Param('id') id: string, @Body() updateEmployeeDto: UpdateEmployeeDto) {
//     return this.employeeService.update(+id, updateEmployeeDto);
//   }

//   @Delete(':id')
//   remove(@Param('id') id: string) {
//     return this.employeeService.remove(+id);
//   }
// }



import { Controller, Get, Post, Body, Patch, Param, Delete, Req } from '@nestjs/common';
import { EmployeeService } from './employee.service';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';


@Controller('employee')
export class EmployeeController {
  constructor(private readonly employeeService: EmployeeService) {}

  @Post('/addDepartment')
  create(@Body() createEmployeeDto: CreateEmployeeDto) {
    return this.employeeService.create(createEmployeeDto);
  }

  // @Post('updateCustomer/'+':id')
  // update(@Param('id') id: string, @Body() updateEmployeeDto: updateEmployeeDto) {
  //   return this.employeeService.update(+id, updateEmployeeDto);
  // }
  @Post('updateDepartment')
  update(@Body() updateEmployeeDto: UpdateEmployeeDto) {
    return this.employeeService.update(updateEmployeeDto);
  }

  @Post('/getAllDepartment')
  findAll() {
    return this.employeeService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.employeeService.findOne(+id);
  }



  // @Delete('/deleteCustomer/'+':id')
  // remove(@Param('id') id: string) {
  //   return this.employeeService.remove(+id);
  // }
   
  @Post('/deleteDepartment')
  removeSoft(@Body() updateEmployeeDto: UpdateEmployeeDto) {
    return this.employeeService.delSoft(updateEmployeeDto);
    
  }

  @Post('getAllDepartmentPagination')
  async findAllEMployee(@Body() findAllCustomerDto) {
    
    try{
      this.employeeService.findAllEmp(findAllCustomerDto,findAllCustomerDto.pagination)
      console.log(findAllCustomerDto)
      return this.employeeService.findAllEmp(findAllCustomerDto,findAllCustomerDto.pagination)
     
    }
    catch(e){
      throw e
    }

//  return this.employeeService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
  }
}
