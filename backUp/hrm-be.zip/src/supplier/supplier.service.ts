// import { Injectable } from '@nestjs/common';
// import { CreateSupplierDto } from './dto/create-supplier.dto';
// import { UpdateSupplierDto } from './dto/update-supplier.dto';

// @Injectable()
// export class SupplierService {
//   create(createSupplierDto: CreateSupplierDto) {
//     return 'This action adds a new supplier';
//   }

//   findAll() {
//     return `This action returns all supplier`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} supplier`;
//   }

//   update(id: number, updateSupplierDto: UpdateSupplierDto) {
//     return `This action updates a #${id} supplier`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} supplier`;
//   }
// }






// import { Injectable } from '@nestjs/common';
// import { createSupplierDto } from './dto/create-supplier.dto';
// import { updateSupplierDto } from './dto/update-supplier.dto';

// @Injectable()
// export class suppliersService {
//   create(createSupplierDto: createSupplierDto) {
//     return 'This action adds a new supplier';
//   }

//   findAll() {
//     return `This action returns all suppliers`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} supplier`;
//   }

//   update(id: number, updateSupplierDto: updateSupplierDto) {
//     return `This action updates a #${id} supplier`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} supplier`;
//   }
// }




import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'rxjs/operators';
import { PaginationDto } from 'src/customer/dto/create-customer.dto';
import { Supplier } from './entities/supplier.entity';
import { CreateSupplierDto } from './dto/create-supplier.dto';
import { UpdateSupplierDto } from './dto/update-supplier.dto';




@Injectable()
export class SupplierService {
     
  constructor(@InjectRepository(Supplier) private readonly supplierRepo:Repository<Supplier>){}

  create(createSupplierDto:CreateSupplierDto):Promise<Supplier> {
    const supplier=new Supplier();
    supplier.name=createSupplierDto.name;
    supplier.description=createSupplierDto.description;
    supplier.code=createSupplierDto.code;
    supplier.creditLimit=createSupplierDto.creditLimit;
    supplier.address=createSupplierDto.address;
    supplier.email=createSupplierDto.email;
    supplier.mobileNumber=createSupplierDto.mobileNumber;
    supplier.startingBalance=createSupplierDto.startingBalance;
    supplier.dmlStatus=1;
    supplier.timeStamp=Date()
    return  this.supplierRepo.save(supplier);
  }

  findAll():Promise<Supplier[]> {
    return this.supplierRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} supplierer`;
  }

  update(updateSupplierDto:UpdateSupplierDto) {
    const supplier= new Supplier();
    supplier.name=updateSupplierDto.name;
    supplier.description=updateSupplierDto.description;
    supplier.code=updateSupplierDto.code;
    supplier.creditLimit=updateSupplierDto.creditLimit;
    supplier.address=updateSupplierDto.address;
    supplier.email=updateSupplierDto.email;
    supplier.mobileNumber=updateSupplierDto.mobileNumber;
    supplier.startingBalance=updateSupplierDto.startingBalance;
    supplier.id=updateSupplierDto.id,
    supplier.dmlStatus=2;
    supplier.timeStamp=Date()
    return  this.supplierRepo.save(supplier);
  }


  // remove(id: number) {
  //   return this.supplierRepo.delete(id);
  // }

  delSoft(updateSupplierDto:UpdateSupplierDto) {
    const supplier=new Supplier();
    supplier.name=updateSupplierDto.name;
    supplier.description=updateSupplierDto.description;
    supplier.code=updateSupplierDto.code;
    supplier.creditLimit=updateSupplierDto.creditLimit;
    supplier.address=updateSupplierDto.address;
    supplier.email=updateSupplierDto.email;
    supplier.mobileNumber=updateSupplierDto.mobileNumber;
    supplier.startingBalance=updateSupplierDto.startingBalance;
    supplier.dmlStatus=3;
    supplier.timeStamp=Date()
    return this.supplierRepo.save(supplier);
  }

  async findAllSupplier(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` supplierer.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and supplierer.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and supplierer.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and supplierer.address like '%${params?.address}%' and `;
    }
     
    sql += ` supplierer.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.supplierRepo
      .createQueryBuilder('supplierer')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.supplierRepo
      .createQueryBuilder('supplierer')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
