export class CreateDesignationDto {
    name:string;
    description:string;
    dmlStatus:number;
    timeStamp:string
}
