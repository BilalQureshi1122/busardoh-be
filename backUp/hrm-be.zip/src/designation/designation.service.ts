// import { Injectable } from '@nestjs/common';
// import { CreateDesignationDto } from './dto/create-designation.dto';
// import { UpdateDesignationDto } from './dto/update-designation.dto';

// @Injectable()
// export class DesignationService {
//   create(createDesignationDto: CreateDesignationDto) {
//     return 'This action adds a new designation';
//   }

//   findAll() {
//     return `This action returns all designation`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} designation`;
//   }

//   update(id: number, updateDesignationDto: UpdateDesignationDto) {
//     return `This action updates a #${id} designation`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} designation`;
//   }
// }


// import { Injectable } from '@nestjs/common';
// import { createDesignationDto } from './dto/create-designation.dto';
// import { updateDesignationDto } from './dto/update-designation.dto';

// @Injectable()
// export class DepartmentService {
//   create(createDesignationDto: createDesignationDto) {
//     return 'This action adds a new designation';
//   }

//   findAll() {
//     return `This action returns all designation`;
//   }

//   findOne(id: number) {
//     return `This action returns a #${id} designation`;
//   }

//   update(id: number, updateDesignationDto: updateDesignationDto) {
//     return `This action updates a #${id} designation`;
//   }

//   remove(id: number) {
//     return `This action removes a #${id} designation`;
//   }
// }






import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PaginationDto } from 'src/customer/dto/create-customer.dto';
import { Designation } from './entities/designation.entity';
import { CreateDesignationDto } from './dto/create-designation.dto';
import { UpdateDesignationDto } from './dto/update-designation.dto';


@Injectable()
export class DesignationService {
     
  constructor(@InjectRepository(Designation) private readonly designationRepo:Repository<Designation>){}

  create(createDesignationDto:CreateDesignationDto):Promise<Designation> {
    const designation=new Designation();
    designation.name=createDesignationDto.name;
    designation.description=createDesignationDto.description;
    designation.dmlStatus=1;
    designation.timeStamp=Date()
    return  this.designationRepo.save(designation);
  }

  findAll():Promise<Designation[]> {
    return this.designationRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} departmenter`;
  }

  update(updateDesignationDto:UpdateDesignationDto) {
    const designation=new Designation();
    designation.name=updateDesignationDto.name;
    designation.description=updateDesignationDto.description;
    designation.id=updateDesignationDto.id,
    designation.dmlStatus=2;
    designation.timeStamp=Date()
    return  this.designationRepo.save(designation);
  }


  // remove(id: number) {
  //   return this.designationRepo.delete(id);
  // }

  delSoft(updateDesignationDto:UpdateDesignationDto) {
    const designation=new Designation();
    designation.name=updateDesignationDto.name;
    designation.description=updateDesignationDto.description;
    designation.id=updateDesignationDto.id;
    designation.dmlStatus=3;
    designation.timeStamp=Date()
    return this.designationRepo.save(designation);
  }

  async findAllDesignation(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` designation.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and designation.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and designation.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and designation.address like '%${params?.address}%' and `;
    }
     
    sql += ` designation.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.designationRepo
      .createQueryBuilder('designation')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.designationRepo
      .createQueryBuilder('designation')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
