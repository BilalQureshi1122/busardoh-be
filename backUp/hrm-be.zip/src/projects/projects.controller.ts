// import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
// import { ProjectsService } from './projects.service';
// import { CreateProjectDto } from './dto/create-project.dto';
// import { UpdateProjectDto } from './dto/update-project.dto';

// @Controller('projects')
// export class ProjectsController {
//   constructor(private readonly projectsService: ProjectsService) {}

//   @Post()
//   create(@Body() createProjectDto: CreateProjectDto) {
//     return this.projectsService.create(createProjectDto);
//   }

//   @Get()
//   findAll() {
//     return this.projectsService.findAll();
//   }

//   @Get(':id')
//   findOne(@Param('id') id: string) {
//     return this.projectsService.findOne(+id);
//   }

//   @Patch(':id')
//   update(@Param('id') id: string, @Body() updateProjectDto: UpdateProjectDto) {
//     return this.projectsService.update(+id, updateProjectDto);
//   }

//   @Delete(':id')
//   remove(@Param('id') id: string) {
//     return this.projectsService.remove(+id);
//   }
// }





import { Controller, Get, Post, Body, Patch, Param, Delete, Req } from '@nestjs/common';
import { ProjectsService } from './projects.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';


@Controller('project')
export class ProjectsController {
  constructor(private readonly projectService: ProjectsService) {}

  @Post('/addProject')
  create(@Body() createProjectDto: CreateProjectDto) {
    return this.projectService.create(createProjectDto);
  }

  // @Post('updateCustomer/'+':id')
  // update(@Param('id') id: string, @Body() updateProjectDto: updateProjectDto) {
  //   return this.projectService.update(+id, updateProjectDto);
  // }
  @Post('updateProject')
  update(@Body() updateProjectDto: UpdateProjectDto) {
    return this.projectService.update(updateProjectDto);
  }

  @Post('/getAllProject')
  findAll() {
    return this.projectService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.projectService.findOne(+id);
  }



  // @Delete('/deleteCustomer/'+':id')
  // remove(@Param('id') id: string) {
  //   return this.projectService.remove(+id);
  // }
   
  @Post('/deleteProject')
  removeSoft(@Body() updateProjectDto: UpdateProjectDto) {
    return this.projectService.delSoft(updateProjectDto);
    
  }

  @Post('getAllProjectPagination')
  async findAllCustomer(@Body() findAllCustomerDto) {
    
    try{
      this.projectService.findAllProject(findAllCustomerDto,findAllCustomerDto.pagination)
      console.log(findAllCustomerDto)
      return this.projectService.findAllProject(findAllCustomerDto,findAllCustomerDto.pagination)
     
    }
    catch(e){
      throw e
    }

//  return this.projectService.findAllCustomer(findAllCustomerDto,findAllCustomerDto.pagination)
  }
}
