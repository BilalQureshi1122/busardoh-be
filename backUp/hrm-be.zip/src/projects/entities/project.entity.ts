import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Project {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  description: string;

  @Column()
  startDate: string;

  @Column()
  endDate: string;

  @Column()
  income: string;

  @Column()
  directCost: string;

  @Column()
  profit: string;

  @Column()
  status: string;

  @Column()
  dmlStatus: number;

  @Column()
  timeStamp:string

 
}