import { Injectable } from '@nestjs/common';
import { CreateCustomerDto, FindAllCustomerDto, PaginationDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { Customer } from './entities/customer.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'rxjs/operators';



@Injectable()
export class CustomerService {
     
  constructor(@InjectRepository(Customer) private readonly customerRepo:Repository<Customer>){}

  create(createCustomerDto:CreateCustomerDto):Promise<Customer> {
    const custom=new Customer();
    custom.name=createCustomerDto.name;
    custom.email=createCustomerDto.email;
    custom.phoneNumber=createCustomerDto.phoneNumber;
    custom.address=createCustomerDto.address;
    custom.dmlStatus=1;
    custom.timeStamp=Date()
    return  this.customerRepo.save(custom);
  }

  findAll():Promise<Customer[]> {
    return this.customerRepo.find();
  }


  findOne(id: number) {
    return `This action returns a #${id} customer`;
  }

  update(updateCustomerDto:UpdateCustomerDto) {
    const custom=new Customer();
    custom.name=updateCustomerDto.name;
    custom.email=updateCustomerDto.email;
    custom.phoneNumber=updateCustomerDto.phoneNumber;
    custom.address=updateCustomerDto.address;
    custom.id=updateCustomerDto.id,
    custom.dmlStatus=2;
    custom.timeStamp=Date()
    return  this.customerRepo.save(custom);
  }


  // remove(id: number) {
  //   return this.customerRepo.delete(id);
  // }

  delSoft(updateCustomerDto:UpdateCustomerDto) {
    const custom=new Customer();
    custom.name=updateCustomerDto.name;
    custom.email=updateCustomerDto.email;
    custom.phoneNumber=updateCustomerDto.phoneNumber;
    custom.address=updateCustomerDto.address;
    custom.id=updateCustomerDto.id;
    custom.dmlStatus=3;
    custom.timeStamp=Date()
    return this.customerRepo.save(custom);
  }

  

  // async findAllCustomer(params,pagination:PaginationDto){
   
  //   console.log(params);
  //   let sql = '';
  //   if (params?.name !== '') {
  //     sql += `customer.name like '%${params?.name}%' AND `;
  //   }
  //   if (params?.email !== '') {
  //     sql += `customer.email like '%${params?.email}%' AND `;
  //   }
  //   if (params?.phoneNumber !== '') {
  //     sql += `customer.phoneNumber like '%${params?.phoneNumber}%' AND `;
  //   }
  //   if (params?.address !== '') {
  //     sql += `customer.address like '%${params?.address}%'`;
  //   }
  //   console.log('query',sql)
  //   const count = await this.customerRepo
  //     .createQueryBuilder('customer')
  //     .where(sql)
  //     .getCount();
  //   if (pagination &&
  //     pagination?.pageNo >= 0 &&
  //     pagination?.itemsPerPage > 0
  //   ) {
  //     sql += ` OFFSET ${
  //       pagination?.pageNo * pagination?.itemsPerPage
  //     } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
  //   }

  //   const query = await this.customerRepo
  //     .createQueryBuilder('customer')
  //     .where(sql)
  //     .getMany();
  //   return [query, count];
  // }




  async findAllCustomer(params,pagination:PaginationDto){
   
    console.log(params);
    let sql = '';
    if (params?.name) {
      sql += ` customer.name like '%${params?.name}%' `;
    }
    if (params?.email) {
      sql += ` and customer.email like '%${params?.email}%' `;
    }
    if (params?.phoneNumber) {
      sql += ` and customer.phoneNumber like '%${params?.phoneNumber}%' `;
    }
    if (params?.address) {
      sql += ` and customer.address like '%${params?.address}%' and `;
    }
     
    sql += ` customer.dmlStatus != 3`;

    console.log('query',sql)
    const count = await this.customerRepo
      .createQueryBuilder('customer')
      .where(sql)
      .getCount();
    if (pagination &&
      pagination?.pageNo >= 0 &&
      pagination?.itemsPerPage > 0
    ) {
      sql += ` OFFSET ${
        pagination?.pageNo * pagination?.itemsPerPage
      } ROWS FETCH NEXT ${pagination?.itemsPerPage} ROWS ONLY`;
    }

    const query = await this.customerRepo
      .createQueryBuilder('customer')
      .where(sql)
      .getMany();
    return [query, count];
  }
}
